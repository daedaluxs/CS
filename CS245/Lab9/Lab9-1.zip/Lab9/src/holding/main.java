package holding;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.*;

/**
 * simply GUI dispaly program
 * @author keegan grottodden
 *
 */
public class main extends JFrame{
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,500);
		frame.setLayout(new BorderLayout());
		frame.setVisible(true);
		JLabel tester = new JLabel();
		tester.setText("OPEN");
		JLabel label1 = new JLabel("",SwingConstants.CENTER);
		label1.setText("Basic GUI Developement");
		Font font = new Font("", Font.ITALIC,24);
		label1.setFont(font);
		label1.setOpaque(true);
		//---------------------------------------------
		JFrame frame2 = new JFrame();
		JLabel label2 = new JLabel("",SwingConstants.CENTER);
		label2.setText("Advanced Programming");
		Font font2 = new Font("", Font.ITALIC+Font.BOLD,24);
		label2.setFont(font2);
		label2.setOpaque(true);
							
		frame2.setSize(300,300);
		label2.setBackground(Color.red);
		frame2.setLayout(new BorderLayout());
		
		frame2.add(label2);		
		JButton zeButton = new JButton("Keegan Grottodden");
		Font font3 = new Font("", Font.BOLD,16);
		zeButton.setFont(font3);
		//----------------------------------------------
		
		zeButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{	
					frame2.setVisible(true);
				
				}
			});
		
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		label1.setBackground(Color.red);
		panel2.setBackground(Color.blue);
		panel3.setBackground(Color.green);
		panel4.setBackground(Color.orange);
		
		label1.setPreferredSize(new Dimension(90,90));
		panel2.setPreferredSize(new Dimension(90,90));
		panel3.setPreferredSize(new Dimension(90,90));
		panel4.setPreferredSize(new Dimension(90,90));

		frame.add(zeButton);
		
		frame.add(panel2,BorderLayout.EAST);
		frame.add(panel3,BorderLayout.SOUTH);
		frame.add(panel4,BorderLayout.WEST);
		frame.add(label1,BorderLayout.NORTH);
		
	}
	
}
