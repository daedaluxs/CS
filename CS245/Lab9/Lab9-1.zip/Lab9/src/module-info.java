module Lab9 {
	requires java.desktop;
}