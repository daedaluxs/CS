module Lab10 {
	requires java.desktop;
}