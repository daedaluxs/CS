package holding;

import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.*;

public class main extends JFrame{
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,500);
		

		 UIManager UI=new UIManager();
		 UI.put("OptionPane.background",new ColorUIResource(250,0,50));
		 UI.put("Panel.background",new ColorUIResource(250,0,50));

		
		JMenuBar MenuBar = new JMenuBar();
		
		JMenu FileMenu = new JMenu("File");
		JMenu EditMenu = new JMenu("Edit");

		JMenuItem New = new JMenuItem("New");
		JMenuItem NewWin = new JMenuItem("New Window");
		JMenuItem Save = new JMenuItem("Save");
		JMenuItem Print = new JMenuItem("Print");
		JMenuItem Exit = new JMenuItem("Exit");
		
		JMenuItem Undo = new JMenuItem("Undo");
		JMenuItem Cut = new JMenuItem("Cut");
		JMenuItem Copy = new JMenuItem("Copy");
		JMenuItem Paste = new JMenuItem("Paste");
		JMenuItem Delete = new JMenuItem("Delete");

		JTextArea type = new JTextArea();
		
		FileMenu.add(New);
		FileMenu.add(NewWin);
		FileMenu.add(Save);
		FileMenu.add(Print);
		FileMenu.add(Exit);
		
		EditMenu.add(Undo);
		EditMenu.add(Cut);
		EditMenu.add(Copy);
		EditMenu.add(Paste);
		EditMenu.add(Delete);

		MenuBar.add(FileMenu);
		MenuBar.add(EditMenu);
		
		NewWin.addActionListener(e ->{
			new DialogBox("Opens notepad in new window",1);
		});
		Delete.addActionListener(e ->{
			new DialogBox("Deletes Content",2);
		});
		
		New.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Opens new notepad","ALERT!!",1);
		});
		Save.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Saves notepad","ALERT!!",1);
		});
		Print.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Prints notepad","ALERT!!",1);
		});
		Exit.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Exits notepad","ALERT!!",1);
		});
		Undo.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Undo Last edit","ALERT!!",1);
		});
		Copy.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Copies","ALERT!!",1);
		});
		Cut.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Cuts","ALERT!!",1);
		});
		Paste.addActionListener(e ->{
			JOptionPane.showMessageDialog(null,"Pastes","ALERT!!",1);
		});
		
		frame.add(type);
		frame.setJMenuBar(MenuBar);
		MenuBar.setVisible(true);
		frame.setVisible(true);


	}
}
