package holding;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class DialogBox extends JFrame{

	DialogBox(){
		
	}
	
	 DialogBox(String Param,int num){
		JFrame frame = new JFrame();
		
		
		frame.setSize(400,400);
		JButton zeButton = new JButton("Delete");
		JLabel label1 = new JLabel("",SwingConstants.CENTER);
		
		zeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{	
				System.out.println("The Selected Text Has Been Deleted");			
			}
		});
		if(num==2) {
			zeButton.setVisible(true);
		}
		else {
			zeButton.setVisible(false);
		}
		label1.setText(Param);
		
		zeButton.setPreferredSize(new Dimension(90,25));
		frame.add(zeButton,BorderLayout.SOUTH);
		frame.add(label1);
		frame.setVisible(true);
	}

	
	
	
}
