package holding;

import java.io.IOException;

public class main {

	static logic obj = new logic();
	
	public static void main(String args[]) {
		
		obj.generate();
		
		
		
		obj.regenerate();
		
		obj.printagain();
	}	
	
}