package holding;
import java.util.Random;
import java.util.ArrayList;

public class logic {
	ArrayList<Integer> nums = new ArrayList<Integer>();
	ArrayList<Integer> nums2 = new ArrayList<Integer>();
	int temp =0;
	public void generate() {
		for(int i=0;i<25;i++) {
			Random rand = new Random();
			temp = rand.nextInt(100) + 1;
			
			nums.add(i);
			nums.set(i,temp);
			
		}
	}
	
	public void regenerate() {
		
		for(int i=0;i<25;i++) {
			nums2.add(i);
			nums2.set(i, nums.get(24-i));
		}
	}
	public void printagain() {
		for(int i=0;i<25;i++) {
			System.out.println(nums.get(i) + " | " + nums2.get(i));
		}
			
	}
	
}
