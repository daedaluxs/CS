module Lab3 {
}