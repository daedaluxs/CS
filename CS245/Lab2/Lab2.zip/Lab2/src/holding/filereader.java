package holding;

import java.io.IOException;
import java.util.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;  
import java.io.FileWriter;

public class filereader {

	static String fileinput = "Lab_2_Input.txt";
	static String fileoutput = "Lab_2_Output.txt";
	private int[] numarray = new int[20];
	int count = 0;
	boolean attempt;
	
	public void scanner() throws IOException {
		Path path = Paths.get(fileinput);
		Scanner scanner = new Scanner(path);
		while(scanner.hasNextLine()){
		    String line = scanner.nextLine();
		    //populating array
		    numarray[count] = Integer.parseInt(line);
		    count++;
		}
		scanner.close();
	}
	
	public void filewriter() throws IOException{
		//generating file
		File newfile = new File(fileoutput);

		try{

			newfile.createNewFile();
		}
		catch(Exception e) {
			System.out.println("File Alreaddy Exists");
		}
		FileWriter writer = new FileWriter(fileoutput);
		for(int i=19;i>=0;i--) {
			writer.write((int)numarray[i] + "\n");
		}
		writer.close();
	}
}

	

