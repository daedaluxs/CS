package holding;

import java.io.IOException;

public class main {

	static filereader obj = new filereader();
	
	public static void main(String args[]) throws IOException {
		
		obj.scanner();
		obj.filewriter();
		
	}	
	
}
