module Assignment3 {
	exports holding;
}