package holding;

/**
 *  Keegan Grottodden CS 245 Assignment 3
A list iterator allows access of a position in a linked list.    
This interface contains a subset of the methods of the 
standard java.util.ListIterator interface. 
*/
public interface ListIterator
{  
/**
   Moves the iterator past the next element.
   @return the traversed element
*/
Object next();
   
/**
   Tests if there is an element after the iterator position.
   @return true if there is an element after the iterator position
*/
boolean hasNext();
   
/**
   Adds an element before the iterator position
   and moves the iterator past the inserted element.
   @param element the element to add
*/
void add(Object element);
   
/**
 * shifts alternating elements to the end of the linked list
 */
void shift();
/**
 * assistance function to shift()
 */
void activate();

}

