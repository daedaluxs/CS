package holding;
/**
 *  Keegan Grottodden CS 245 Assignment 3
A program that demonstrates the LinkedList class
*/
public class main
{  

public static void main(String[] args)
{  
   LinkedList list = new LinkedList();
   ListIterator iterator = list.listIterator();
   
   // Use the iterator so that list has (in order) these elements
   // Tom->Romeo->Harry->Diana->Juliet->Nina
   iterator.add(10);
   iterator.add(31);
   iterator.add(42);
   iterator.add(23);
   iterator.add(44);
   iterator.add(75);
   iterator.add(86);
  


   // Print all the elements of list
   iterator = list.listIterator();
   while (iterator.hasNext())
   {
      System.out.print(iterator.next() + " ");
   }
   System.out.println();
         
   // Call removeLast() to delete the last element of the list

   iterator = list.listIterator();
   iterator.shift();

   // Print all the elements of list
   iterator = list.listIterator();
   while (iterator.hasNext())
   {
      System.out.print(iterator.next() + " ");
   }
   System.out.println();
}
}

