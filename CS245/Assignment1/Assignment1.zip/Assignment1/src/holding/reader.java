package holding;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
/*
 * Keegan Grottodden
 * CS245-001
 * Holds methods which complete the assigned tasks, to be run in the main. 
 * 
 */
public class reader {
	//the story
	ArrayList<String> story = new ArrayList<String>();	
	// a "new" unchanging copy of the story.
	ArrayList<String> n = new ArrayList<String>();	
	//list of morocco-esq words
	ArrayList<String> toremove = new ArrayList<String>();
	
	static String fileoutput = "Assignment_1_Output.txt";
	
	ArrayList<String> finalout = new ArrayList<String>();
	
	static String file = "writingsample-1.txt";
	public void read() throws IOException {
		Path path = Paths.get(file);
		Scanner scanner = new Scanner(path);
		while(scanner.hasNext()) {
			String nword = scanner.next();
		     nword = nword.replace(",", "");
		     nword = nword.replace("�", "");
		     nword = nword.replace("'", "");
		     nword = nword.replace("�", "");
		     nword = nword.replace(".", "");
		     nword = nword.replace("?", "");
		     nword = nword.replace("�", "");
		     nword = nword.replace("�", "");
		     nword = nword.replace("�", "");
		     nword = nword.replace(",", "");
		     nword = nword.replace("-", "");
		     nword = nword.toLowerCase();
			 story.add(nword);	
			 n.add(nword);	
		}
		scanner.close();
	}
	public void length() {
		finalout.add("Number of words: " + story.size());
	}
	
	public void uniques() {
		int count = 1;
		int uncount =0;
		int uncount2 =0;
		finalout.add("Words and their frequency:");
		for(int i=0;i<story.size();i++) {
			count = 1;
			for(int j=i+1;j<story.size();j++) {
				if(story.get(i).equals(story.get(j))){
					story.remove(j);
					count++;
				}
			}
			String spacing = "-";
			for(int k=14-story.get(i).length();k>=0;k--) {
				spacing = spacing + "-";
			}
			finalout.add(story.get(i)+ spacing+ "| " + count);
			
			
			if(count==1) {
					
				uncount++;
			}
			if(count!=1) {
				
				uncount2++;
			}
		}
		int comb = uncount2+uncount;
		finalout.add("Number of true unique words: " + uncount);	
		finalout.add("Number of unique words: " + comb + " (Words used at least once)");
	}
	
	public void sp() {
		int num =0;
		toremove.add("morocco");
		toremove.add("moroccan");
		toremove.add("moroccans");
		for(int i=0;i<n.size();i++) {
			for(int j=0;j<3;j++) {
				if(n.get(i).equals(toremove.get(j))){
					num++;	
					n.remove(i);	
				}
			}
		}
		finalout.add("Number of Morocco-esq words removed: " + num);
	}
	public void filewriter() throws IOException{
		//generating file
		File newfile = new File(fileoutput);

		try{

			newfile.createNewFile();
		}
		catch(Exception e) {
			System.out.println("File Alreaddy Exists");
		}
		FileWriter writer = new FileWriter(fileoutput);
		for(int i=0;i<finalout.size();i++) {
			writer.write( finalout.get(i)+ "\n");
		}
		writer.close();
	}
}
