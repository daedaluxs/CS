package holding;

import java.io.IOException;
/*
 * Keegan Grottodden
 * CS245-001
 * Runs the methods in proper order from the "reader" file.
 * 
 */
public class main {
static reader obj = new reader();
	public static void main(String args[]) throws IOException {
		obj.read();
		obj.length();
		obj.uniques();
		obj.sp();
		obj.filewriter();
	}	
}
