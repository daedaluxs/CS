package holding;

import java.util.ArrayList;
import java.util.Random;
/*
 * Keegan Grottodden
 * This program generates arrays of random length with random values,
 * and weaves those generated arrays together.
 */
public class logic {
	int tempsize = 0;
	int a1c=0;
	int a2c=0;
	/*
	 * Weaving the arrays
	 */
	public void interleave(ArrayList<Integer> a1, ArrayList<Integer> a2) {
		
				// A1 PRINT
				System.out.print("A1 LINE-");
				for(int i=0;i<a1.size();i++) {
					System.out.print(a1.get(i) + " ");
				}
				// A2 PRINT
				System.out.println();
				System.out.print("A2 LINE-");
				for(int i=0;i<a2.size();i++) {
					System.out.print(a2.get(i) + " ");
				}
		while(a1c < a1.size() && a2c < a2.size()) {
				a1c++;
				a1.add(a1c, a2.get(a2c));	
				a2c++;	
				a1c++;
		} 
		while(a2c < a2.size()) {
			a1.add(a2.get(a2c));
			a2c++;
		}
				System.out.println();
				//OVERALL PRINT
				for(int i=0;i<a1.size();i++) {
				System.out.print(a1.get(i) + " ");
		}	
	}
	 /*
	  * Generating the arrays.
	  */
	public ArrayList<Integer> generate(){
		ArrayList<Integer> nums = new ArrayList<Integer>();
		Random rand = new Random();
		tempsize = rand.nextInt(15) + 10;
		while(nums.size() <= tempsize) {
			nums.add(rand.nextInt(50) + 1);
		}
		return nums;	
	}
}
 