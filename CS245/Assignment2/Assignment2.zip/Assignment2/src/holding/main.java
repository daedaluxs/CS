package holding; 
public class main {
	static logic obj = new logic();
	public static void main(String args[]){
		obj.interleave(obj.generate(), obj.generate());
	}	
}
