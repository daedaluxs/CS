module Lab8 {
}