package holding;

import java.io.IOException;
/**
 * Program detects whether an array of numbers is a palidrome or not.
 * @author keega
 *
 */
public class main {

	static logic obj = new logic();
	public static void main(String args[]) throws IOException {
		int[] nums2 = {1,2,3,4,3,2,1};
		

		obj.load(nums2);
		System.out.println(obj.isPalindrome());
		
		int[] nums3 = {3,4,55,4,2};
		obj.load(nums3);
		System.out.println(obj.isPalindrome());
		
		int[] nums4 = {66,43,6,6,43,66};
		obj.load(nums4);
		System.out.println(obj.isPalindrome());
		
		int[] nums5 = {};
		obj.load(nums5);
		System.out.println(obj.isPalindrome());
	}
}
