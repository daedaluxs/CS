package holding;

import java.util.Stack;

public class logic {
	boolean center = true; //odd
	Stack<Integer>trace=new Stack<Integer>();
	Stack<Integer>queue=new Stack<Integer>();

	int[] nums2 = {};
	boolean sec = false;
	/*
	 * Compiles the stack from nums array.
	 */
	public Stack<Integer> load(int[] nums) {
		nums2 = nums;
		if(nums.length%2==0) {
			center=false;
		}
		sec = center;
		queue.clear();
		for(int x =0; x<nums.length;x++) {
			queue.push(nums[x]);
		}
		return queue;
	}
	/**
	 * Finds if there is a palidrome
	 * @return [s] true or false if there is one or not.
	 */
	public boolean isPalindrome() {
		int traverse = nums2.length / 2;
		int count = 0;
		while(queue.size()>0) {
			count++;
			if(count<=traverse) {
				int popped = queue.pop();
				trace.push(popped);
			}
			
			if(center && count == traverse) {
			    queue.pop();
				center = false;
			}
			
			if(count>traverse) {
				if(trace.pop() != queue.pop()) {
					load(nums2);
					System.out.println("Re-Queue: "+queue);
					return false;
				}
			}

		}
		load(nums2);
		System.out.println("Re-Queue: "+queue);
		return true;
		
	}
	
	
	
}
