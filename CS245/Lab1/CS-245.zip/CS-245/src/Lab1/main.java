package Lab1;

public class main {
 static NumArray numarray = new NumArray();
	public static void main( String args[] )   
	{  
		
		numarray.numGen();
		numarray.PRINTARRAY();
		numarray.AVERAGETEST();
		numarray.MAXMINTEST();
		numarray.SORTTEST();
	}
	
	
}
