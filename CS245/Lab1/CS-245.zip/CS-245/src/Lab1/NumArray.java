
package Lab1;

import java.lang.Math;
import java.util.Arrays;


public class NumArray {
	int[] intArray = new int[26]; 
	
	 int min = 1;
	 int max = 500;
	 
	public void numGen() {
	for (int i = 0; i <= 25; i++) {
		intArray[i]=(int)(Math.random()*(max - min + 1) + min);
		
	}
	
}
	public void PRINTARRAY() {
		for (int i=0; i<=25; i++) {
			System.out.println(intArray[i]);
		
		}
	}
	
	public void AVERAGETEST() {
		int total = 0;
		for (int i=0; i<=25; i++) {
			
			total += intArray[i];
			
		}
		System.out.println("AVERAGE: "+ total / 25);
	}
	
	public void MAXMINTEST() {
		int max = 0;
		int min = 500;
		
		for (int i=0; i<=25; i++) {
			if(intArray[i]<min) {
				min=intArray[i];
			}
			if(intArray[i]>max) {
				max=intArray[i];
			}
			
		}
		
		System.out.println("MAX: "+ max +" MIN: " + min);
		
	}
	
	public void SORTTEST() {
		
		Arrays.sort(intArray);
		
		for (int n=0; n<=25; n++) {
			System.out.println(intArray[n]);
		
		}
	}
}