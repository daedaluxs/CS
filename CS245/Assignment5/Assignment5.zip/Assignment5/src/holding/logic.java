package holding;

import java.util.ArrayList;
import java.util.Random;
/**
 * Binary Search Tree structure and traversal methods.
 * @author keegan grottodden
 *
 */
class BinarySearchTree {
	
	/* Class containing left
	and right child of current node and key value*/
	class Node {
		int key;
		Node left;
		Node right;

		public Node(int item)
		{
			key = item;
			left = null;
			right = null;
		}
	}

	// Root of BST
	Node root;

	// Constructor
	BinarySearchTree() { 
		root = null; 
	}

	// This method mainly calls deleteRec()
	void deleteKey(int key) { 
		root = deleteRec(root, key); 
	}

	/* A recursive function to
	delete an existing key in BST
	*/
	Node deleteRec(Node root, int key)
	{
		/* Base Case: If the tree is empty */
		if (root == null)
			return root;

		/* Otherwise, recur down the tree */
		if (key < root.key)
			root.left = deleteRec(root.left, key);
		else if (key > root.key)
			root.right = deleteRec(root.right, key);

		// if key is same as root's
		// key, then this is the
		// node to be deleted
		else {
			// node with only one child or no child
			if (root.left == null)
				return root.right;
			else if (root.right == null)
				return root.left;

			// node with two children: Get the inorder
			// successor (smallest in the right subtree)
			root.key = minValue(root.right);

			// Delete the inorder successor
			root.right = deleteRec(root.right, root.key);
		}

		return root;
	}

	int minValue(Node root)
	{
		int minv = root.key;
		while (root.left != null)
		{
			minv = root.left.key;
			root = root.left;
		}
		return minv;
	}

	// This method mainly calls insertRec()
	void insert(int key) { 
		root = insertRec(root, key); 
	}

	/* A recursive function to
	insert a new key in BST */
	Node insertRec(Node root, int key)
	{

		/* If the tree is empty,
		return a new node */
		if (root == null) {
			root = new Node(key);
			return root;
		}

		/* Otherwise, recur down the tree */
		if (key < root.key)
			root.left = insertRec(root.left, key);
		else if (key > root.key)
			root.right = insertRec(root.right, key);

		/* return the (unchanged) node pointer */
		return root;
	}

	void postorder() { 
		printPostorder(root); 
	}
	void inorder() { 
		printInorder(root); 
	}
	void preorder() { 
		printPreorder(root); 
	}
	
	
	int height(Node root)
    {
        if (root == null)
            return 0;
        else {
            /* compute  height of each subtree */
            int lheight = height(root.left);
            int rheight = height(root.right);
 
            /* use the larger one */
            if (lheight > rheight)
                return (lheight + 1);
            else
                return (rheight + 1);
        }
    }
	void printCurrentLevel(Node root, int level)
    {
        if (root == null)
            return;
        if (level == 1)
            System.out.print(root.key + " ");
        else if (level > 1) {
            printCurrentLevel(root.left, level - 1);
            printCurrentLevel(root.right, level - 1);
        }
    }
	void levelorder()
    {
        int h = height(root);
        int i;
        for (i = 1; i <= h; i++)
            printCurrentLevel(root, i);
    }
	void printPostorder(Node node)
    {
        if (node == null)
            return;
 
        // first recur on left subtree
        printPostorder(node.left);
 
        // then recur on right subtree
        printPostorder(node.right);
 
        // now deal with the node
        System.out.print(node.key + " ");
    }
 
    /* Given a binary tree, print its nodes in inorder*/
    void printInorder(Node node)
    {
        if (node == null)
            return;
 
        /* first recur on left child */
        printInorder(node.left);
 
        /* then print the data of node */
        System.out.print(node.key + " ");
 
        /* now recur on right child */
        printInorder(node.right);
    }
 
    /* Given a binary tree, print its nodes in preorder*/
    void printPreorder(Node node)
    {
        if (node == null)
            return;
 
        /* first print data of node */
        System.out.print(node.key + " ");
 
        /* then recur on left subtree */
        printPreorder(node.left);
 
        /* now recur on right subtree */
        printPreorder(node.right);
    }

}
/**
 * For functions outside of BST scope
 * @author keegan grottodden
 *
 */
public class logic {
	//puts all elements from given arraylist into the bst.
	public void inserter(ArrayList<Integer> arr, BinarySearchTree bst) {
		for(int i=0;i<500;i++) {
			bst.insert(arr.get(i));
		}
		
	}
	
	//generates a 1-500 arraylist, and randomly mixes their positions.
	public ArrayList<Integer> generate(){
		ArrayList<Integer> nums = new ArrayList<Integer>();
		while(nums.size() < 500) {
			nums.add(nums.size()+1);
		}
		for(int x=0;x<500;x++) {
			Random rand = new Random();
			int swap = rand.nextInt(500);
			int temp = nums.get(x);
			nums.set(x, nums.get(swap));
			nums.set(swap, temp);
		}
		return nums;	
	}
}
