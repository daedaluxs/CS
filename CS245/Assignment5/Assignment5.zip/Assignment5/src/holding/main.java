package holding;

import java.io.IOException;
/**
 * running generation and traversal time tests.
 * @author keegan grottodden
 *
 */
public class main {
	static logic obj = new logic();
	static BinarySearchTree tree = new BinarySearchTree();
	public static void main(String args[]) throws IOException {
		long startTime = System.nanoTime();
		obj.inserter(obj.generate(),tree);
		tree.postorder();
		obj.inserter(obj.generate(),tree);
		tree.postorder();
		obj.inserter(obj.generate(),tree);
		tree.postorder();
		obj.inserter(obj.generate(),tree);
		tree.postorder();
		obj.inserter(obj.generate(),tree);
		tree.postorder();
		long elapsedTime = System.nanoTime() - startTime;
		System.out.println("");
		System.out.println("5 runs of postorder took: " + elapsedTime + " nanoseconds, Averaging "+ elapsedTime/5 + " nanoseconds per run. ");
		
		long startTime2 = System.nanoTime();
		obj.inserter(obj.generate(),tree);
		tree.inorder();
		obj.inserter(obj.generate(),tree);
		tree.inorder();
		obj.inserter(obj.generate(),tree);
		tree.inorder();
		obj.inserter(obj.generate(),tree);
		tree.inorder();
		obj.inserter(obj.generate(),tree);
		tree.inorder();
		long elapsedTime2 = System.nanoTime() - startTime2;
		System.out.println("");
		System.out.println("5 runs of inorder took: " + elapsedTime2 + " nanoseconds, Averaging "+ elapsedTime2/5 + " nanoseconds per run. ");
	
		long startTime3 = System.nanoTime();
		obj.inserter(obj.generate(),tree);
		tree.preorder();
		obj.inserter(obj.generate(),tree);
		tree.preorder();
		obj.inserter(obj.generate(),tree);
		tree.preorder();
		obj.inserter(obj.generate(),tree);
		tree.preorder();
		obj.inserter(obj.generate(),tree);
		tree.preorder();
		long elapsedTime3 = System.nanoTime() - startTime3;
		System.out.println("");
		System.out.println("5 runs of preorder took: " + elapsedTime3 + " nanoseconds, Averaging "+ elapsedTime3/5 + " nanoseconds per run. ");
	
		long startTime4 = System.nanoTime();
		obj.inserter(obj.generate(),tree);
		tree.levelorder();
		obj.inserter(obj.generate(),tree);
		tree.levelorder();
		obj.inserter(obj.generate(),tree);
		tree.levelorder();
		obj.inserter(obj.generate(),tree);
		tree.levelorder();
		obj.inserter(obj.generate(),tree);
		tree.levelorder();
		long elapsedTime4 = System.nanoTime() - startTime4;
		System.out.println("");
		System.out.println("5 runs of levelorder took: " + elapsedTime4 + " nanoseconds, Averaging "+ elapsedTime4/5 + " nanoseconds per run. ");

	} 
}
