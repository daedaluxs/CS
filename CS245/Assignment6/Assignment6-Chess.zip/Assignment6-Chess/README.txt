added full movement functionality. Will move piece, and destroy the old one..

the help prompt will only appear once. its annoying. it will appear FIRST time you click an OPEN or NULL piece
square.

I didnt add en passant, castling, pawn double move, or check for checks when moving king. 
Seemed like more than the project calls for, and more than I feel like doing at the moment.

If the project demands any of these additions, please let me know.

-Keegan Grottodden. submitted 12.12.21