package holding;

import java.awt.Color;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
//is the "logic" behind where pieces can move, also setting 
//movable positions/highlights when a piece at a position is called.
public class pieceLogic {
	static int row;
	static int col;
	private Color setcolor;
	private boolean basecolor;
	private boolean highlight;

	
	public void helper(int row,int col, String side) {
		if(row>0&&col>0&&row<9&&col<9) {
			if(!(board.keygrid[row][col].getside() == side)) {
			basecolor = board.keygrid[row][col].isBasecolor();
			if((highlight)) {
	
			    setcolor = basecolor ? new Color(222,222,222) : new Color(111,111,111);
			    board.keygrid[row][col].setBackground(setcolor);
			    board.keygrid[row][col].setmovable(false);
	
				}else {
					//blues
				    setcolor = basecolor ? new Color(145,211,235) : new Color(105,141,235);
	
				    board.keygrid[row][col].setBackground(setcolor);
				    board.keygrid[row][col].setmovable(true);
	
				}
			}
		}
	}
	public void logic(String piece,int row,int col,boolean highlight,String side) {
		this.row=row;
		this.col=col;
		this.highlight = highlight;
		
	switch(piece) {
	case "KnightB":
	case "KnightW":
		//operation 1
		row+=2;
		col+=1;
			helper(row,col,side);
		//operation 2
		row=this.row;
		col=this.col;
		row+=2;
		col-=1;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row-=1;
		col-=2;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row-=1;
		col+=2;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row-=2;
		col-=1;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row-=2;
		col+=1;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row+=1;
		col-=2;
		helper(row,col,side);
		
		row=this.row;
		col=this.col;
		row+=1;
		col+=2;
		helper(row,col,side);
		
		break;
	case "PawnB":
	
		
		row+=1;
		helper(row,col,side);
		col-=1;
		if(row>0&&col>0&&row<9&&col<9) {

			if(board.keygrid[row][col].getpiece()!=null) {
				helper(row,col,side);
			}
		}
		col+=2;
		if(row>0&&col>0&&row<9&&col<9) {

			if(board.keygrid[row][col].getpiece()!=null) {
				helper(row,col,side);
			}
		}
		break;
	case "PawnW":
			
			row-=1;
			helper(row,col,side);
			col-=1;
			if(row>0&&col>0&&row<9&&col<9) {

				if(board.keygrid[row][col].getpiece()!=null) {
					helper(row,col,side);
				}
			}
			col+=2;
			if(row>0&&col>0&&row<9&&col<9) {

				if(board.keygrid[row][col].getpiece()!=null) {
					helper(row,col,side);
				}
			}
			break;
	case "RookW":
	case "RookB":
			//set for direction
			while(row>0&&row<8) {
				row++;
				helper(row,col,side);
				if(board.keygrid[row][col].getside()==side) {
					row+=8;
				}
				else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
					helper(row,col,side);
					row+=8;
				}
					
				
			}
			row=this.row;
			col=this.col;
			while(row>1&&row<9) {
				row--;
				helper(row,col,side);
				if(board.keygrid[row][col].getside()==side) {
					row-=8;
				}
				else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
					helper(row,col,side);
					row-=8;
				}
					
				
			}
			row=this.row;
			col=this.col;
			while(col>0&&col<8) {
				col++;
				helper(row,col,side);
				if(board.keygrid[row][col].getside()==side) {
					col+=8;
				}
				else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
					helper(row,col,side);
					col+=8;
				}
					
				
			}
			row=this.row;
			col=this.col;
			while(col>1&&col<9) {
				col--;
				helper(row,col,side);
				if(board.keygrid[row][col].getside()==side) {
					col-=9;
				}
				else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
					helper(row,col,side);
					col-=9;
				}
					
				
			}
			
		
				
		break;
	case "BishopB":
	case "BishopW":
		while(col>1&&col<9&&row>1&&row<9) {
			col--;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>1&&col<9&&row>0&&row<8) {
			col--;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row+=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>0&&col<8&&row>1&&row<9) {
			col++;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>0&&col<8&&row>0&&row<8) {
			col++;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row+=9;
			}
					
		}

		break;
	case "QueenW":
	case "QueenB":
		while(col>1&&col<9&&row>1&&row<9) {
			col--;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>1&&col<9&&row>0&&row<8) {
			col--;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row+=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>0&&col<8&&row>1&&row<9) {
			col++;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(col>0&&col<8&&row>0&&row<8) {
			col++;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row+=9;
			}
					
		}
		row=this.row;
		col=this.col;
		while(row>0&&row<8) {
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				row+=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				row+=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		while(row>1&&row<9) {
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				row-=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				row-=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		while(col>0&&col<8) {
			col++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		while(col>1&&col<9) {
			col--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
			}
				
			
		}
		break;
	case "KingW":
	case "KingB":
		if(col>1&&col<9&&row>1&&row<9) {
			col--;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		if(col>1&&col<9&&row>0&&row<8) {
			col--;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
				row+=9;
			}
					
		}
		row=this.row;
		col=this.col;
		if(col>0&&col<8&&row>1&&row<9) {
			col++;
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row-=9;
			}
					
		}
		row=this.row;
		col=this.col;
		if(col>0&&col<8&&row>0&&row<8) {
			col++;
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=9;
				row+=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=9;
				row+=9;
			}
					
		}
		row=this.row;
		col=this.col;
		if(row>0&&row<8) {
			row++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				row+=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				row+=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		if(row>1&&row<9) {
			row--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				row-=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				row-=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		if(col>0&&col<8) {
			col++;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col+=8;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col+=8;
			}
				
			
		}
		row=this.row;
		col=this.col;
		if(col>1&&col<9) {
			col--;
			helper(row,col,side);
			if(board.keygrid[row][col].getside()==side) {
				col-=9;
			}
			else if(board.keygrid[row][col].getside()!=null&&board.keygrid[row][col].getside()!=side) {
				helper(row,col,side);
				col-=9;
			}
				
			
		}
			
		break;
	}
	}
	//dumb, i hate this, idc.
	public void help() {
		if(board.keygrid[9][9].gethelp() == true) {
			JFrame parent = new JFrame();
			JCheckBox checkbox = new JCheckBox("This will only show once .. :)");
			checkbox.setSelected(false);
			String message = "\"Knight jumps overpieces in an L shape,\n"
					+ "	Queen moves in all directions, bishop moves diagonally,\r\n"
					+ "	rook moves along ranks and columns.\r\n"
					+ "	kings move a single square to non-check positions\r\n"
					+ " and pawns move one square, with attack posibility 1 square diagonally.  \"";
			Object[] params = {message, checkbox};
			
				board.keygrid[9][9].sethelp(checkbox.isSelected());
			
			parent.add(checkbox);
		    JOptionPane.showMessageDialog(parent,params);
			}
	}
}
