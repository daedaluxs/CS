package holding;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
//just the board. has a method to convert numbers to 
//piece names for the piece gen.
public class board extends JPanel{
	static square[][] keygrid = new square[10][10];
	
	public board() {
	this.setLayout(new GridLayout(8,8));
	
	}
	public static void randomFill() {
	Random rand = new Random();  
    int num4 = rand.nextInt(35)+27; 
		for(int i=0;i<num4;i++) {
			 int num = rand.nextInt(12)+1; 
		     int num2 = rand.nextInt(8)+1; 
		     int num3 = rand.nextInt(8)+1; 
			 piecegen.piecegenG(numtopiece(num),num2,num3);
		}
	}
	
	public static String numtopiece(int numb) {
		String end = "";
		switch(numb) {
		case 1:
			end =  "PawnW";
			break;
		
		case 5:
			end =  "KnightW";
			break;
			
		case 2:
			end =  "BishopW";
			break;
		
		case 3:
			end =  "RookW";
			break;
		
		case 4:
			end =  "QueenW";
			break;
		case 6:
			end =  "KingW";
			break;
		case 7:
			end =  "PawnB";
			break;
		case 8:
			end =  "KnightB";
			break;
		case 9:
			end =  "BishopB";
			break;
		case 10:
			end =  "QueenB";
			break;
		case 11:
			end =  "KingB";
			break;
		case 12:
			end =  "RookB";
			break;
		}
		return end;
	}
	
	

}
