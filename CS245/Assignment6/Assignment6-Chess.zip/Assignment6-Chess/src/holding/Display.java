package holding;

import java.awt.Container;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
//Keegan Grottodden
//12/12/2021
//main display,GUI, of program. Populates array of square objects.
public class Display extends JFrame {

	GridLayout grid = new GridLayout();
	public Display(String name) {
        super(name);
        setResizable(false);
    }
	//0 is white, 1 is black
    public void addComponentsToPane(final Container pane) {
    	board screen = new board();
    	boolean val;
    	int coll = 0;
    	int row = 1;
    	//-------Placing squares ----------
		 for(int i=1; i<72;i++) {
		   	 coll++;
			 if(i%9==0) {
				 i++;
				 row++;
				 coll=1;
			 }
			if(i%2==0) {
				 val = true;
			}
			else {
				val = false;
			}
			square newsquare = new square(90,val,row,coll);
		   	screen.add(newsquare);
		   	board.keygrid[row][coll]=newsquare;	   
		 }
		   	board.randomFill();
		   	
		   	//this is stupid
		   	board.keygrid[9][9]=new square(90,true,70,70);	   

    	pane.add(screen);

    }	
	private static void createAndShowGUI() {
        //Create and set up the window.
        Display frame = new Display("Chess");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Set up the content pane.
		frame.setSize(400,400);

        frame.addComponentsToPane(frame.getContentPane());
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
	public static void main(String args[]) throws IOException {		

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
	}	
}
