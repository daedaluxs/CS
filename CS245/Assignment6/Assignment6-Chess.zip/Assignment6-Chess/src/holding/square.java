package holding;

import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;


public class square extends JButton{
	private Color setcolor;
	private boolean highlight=false;
	private boolean basecolor;
	//=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=
	private String piece=null;
	//=-==-=-=-=--=-==-=-=-=--=-=-=-=-
	 private int col=0;
	 private int row=0;
	 private boolean movable = false;
	 private String side = null;
	 //why
	 public boolean help = true;
	 
	public square(int size, boolean color,int row,int col) {
		setBasecolor(color);
	   	setcolor = color ? new Color(222,222,222) : new Color(111,111,111);
		
	   	this.setPreferredSize(new Dimension(size,size));
	   	this.setOpaque(true);
	   	this.setBorderPainted(false);
	   	this.setBackground(setcolor);
		this.addActionListener(e -> findMoves());
		this.addActionListener(e -> pmove());
		//bad
		this.addActionListener(e -> help());


		Font newButtonFont=new Font(this.getFont().getName(),this.getFont().getStyle(),54);
		
		this.setFont(newButtonFont);
		this.col=col;
		this.row=row;
	}
	
	public String getpiece() {
		
		return piece;
	}
	public void setpiece(String param) {
			
		this.piece = param;
	}
	public void help() {
		if(this.piece==null) {
			pieceLogic pieceLogic = new pieceLogic();
			pieceLogic.help();
		}
	}
	//destroys old piece location highlights..
	public void resetgrid() {
		for(int i=0;i<9;i++) {
			for(int j=1;j<9;j++) {
				if(board.keygrid[i][j] != null && board.keygrid[i][j].isHighlight()) {
					pieceLogic pieceLogic = new pieceLogic();
					pieceLogic.logic(board.keygrid[i][j].getpiece()+board.keygrid[i][j].getside(),
							board.keygrid[i][j].row, board.keygrid[i][j].col,board.keygrid[i][j].isHighlight(),board.keygrid[i][j].getside());
					board.keygrid[i][j].isselect();

				}
			}
		}
	}
	//moves the piece...
	public void pmove() {
		String dapiece = null;
		int prow = 0;
		int pcol = 0;
		String nside = null;
		for(int i=0;i<9;i++) {
			for(int j=1;j<9;j++) {
				if(board.keygrid[i][j] != null && board.keygrid[i][j].isHighlight()) {
					dapiece = board.keygrid[i][j].getpiece();
					nside = board.keygrid[i][j].getside();
					prow=i;
					pcol=j;
					
				}	
			}
			
		}
		
		
		if(ismovable()) {
			if(!(this.isHighlight())) {
				resetgrid();
			}	
			board.keygrid[prow][pcol].setpiece(null);
			board.keygrid[prow][pcol].setText("");
			board.keygrid[prow][pcol].setside(null);

			piecegen.piecegenG(dapiece+nside, row, col);
			
			}
	}
	//swaps clicked square colors.
	public void isselect() {
		if(!(isHighlight())) {
			//highlight colors
	    setcolor = isBasecolor() ? new Color(222,122,222) : new Color(202,32,202);
	   	this.setBackground(setcolor);
	   	setHighlight(true);
		}else {
			//chess board colors
		setcolor = isBasecolor() ? new Color(222,222,222) : new Color(111,111,111);
	   	this.setBackground(setcolor);
	   	setHighlight(false);
		}
		
	}
	//begins piece movable squares identification process.
	public void findMoves() {
		if(!(this.isHighlight())) {
		resetgrid();
		}
		if(piece != null) {
			pieceLogic pieceLogic = new pieceLogic();
			pieceLogic.logic(piece+side, this.row, this.col,this.isHighlight(),this.getside());

			this.isselect();
			
		}
		
	}
/*
 * Getters and setters. Yeah. 
 */
	public boolean isBasecolor() {
		return basecolor;
	}
	public void setBasecolor(boolean basecolor) {
		this.basecolor = basecolor;
	}
	public boolean isHighlight() {
		return highlight;
	}
	public void setHighlight(boolean highlight) {
		this.highlight = highlight;
	}
	public void setmovable(boolean movable) {
		this.movable = movable;
	}
	public boolean ismovable() {
		return movable;
	}
	public String getside() {
		return side;
	}
	public void setside(String side) {
	this.side = side;	
	}
	public void sethelp(boolean dd) {
		help = dd;
	}
	public boolean gethelp() {
		return help;
	}
}
