package holding;

import java.util.ArrayList;

public class piecegen {
	board Board;

		//takes requested piece and position, and sets 
		//appropriate piece values.
		public static void piecegenG(String piece,int rank,int file) {
			switch(piece) {
			case "PawnW":
				board.keygrid[rank][file].setpiece("Pawn");
				board.keygrid[rank][file].setText("\u2659");
				board.keygrid[rank][file].setside("W");
				break;
			case "KnightW": 
				board.keygrid[rank][file].setpiece("Knight");
				board.keygrid[rank][file].setText("\u2658");
				board.keygrid[rank][file].setside("W");
				break;
			case "BishopW":
				board.keygrid[rank][file].setpiece("Bishop");
				board.keygrid[rank][file].setText("\u2657");
				board.keygrid[rank][file].setside("W");
				break;
			case "RookW":
				board.keygrid[rank][file].setpiece("Rook");
				board.keygrid[rank][file].setText("\u2656");
				board.keygrid[rank][file].setside("W");
				break;
			case "QueenW":
				board.keygrid[rank][file].setpiece("Queen");
				board.keygrid[rank][file].setText("\u2655");
				board.keygrid[rank][file].setside("W");
				break;
			case "KingW":
				board.keygrid[rank][file].setpiece("King");
				board.keygrid[rank][file].setText("\u2654");
				board.keygrid[rank][file].setside("W");
				break;
				//=-=-=--=-=-=-=-=-==-==-=-=-=-=-=-
			case "PawnB":
				board.keygrid[rank][file].setpiece("Pawn");
				board.keygrid[rank][file].setText("\u265F");
				board.keygrid[rank][file].setside("B");
				break;
			case "KnightB": 
				board.keygrid[rank][file].setpiece("Knight");
				board.keygrid[rank][file].setText("\u265E");
				board.keygrid[rank][file].setside("B");
				break;
			case "BishopB":
				board.keygrid[rank][file].setpiece("Bishop");
				board.keygrid[rank][file].setText("\u265D");
				board.keygrid[rank][file].setside("B");
				break;
			case "RookB":
				board.keygrid[rank][file].setpiece("Rook");
				board.keygrid[rank][file].setText("\u265C");
				board.keygrid[rank][file].setside("B");
				break;
			case "QueenB":
				board.keygrid[rank][file].setpiece("Queen");
				board.keygrid[rank][file].setText("\u265B");
				board.keygrid[rank][file].setside("B");
				break;
			case "KingB":
				board.keygrid[rank][file].setpiece("King");
				board.keygrid[rank][file].setText("\u265A");
				board.keygrid[rank][file].setside("B");
				break;
			}
			}
		
		
	
}
