package holding;

import java.util.HashMap;

public class main {
	
	static HashMap<String, Integer> map = new HashMap<String, Integer>();
	static HashMap<String, Integer> map2 = new HashMap<String, Integer>();
	
	static logic obj = new logic();
	
	public static void main(String[] args) {
		map.put("Janet ", 21);
		map.put("Logan", 62);
		map.put("Jeff", 88);
		map.put("Stefanie",80 );
		map.put("Herald",22 );
		map.put("Jimmy", 69);
		
		map2.put("Janet ", 21);
		map2.put("Logan", 62);
		map2.put("Jeff", 88);
		map2.put("Stefanie",80 );
		map2.put("Herald",42 );
		map2.put("Carter", 69);
		System.out.println(obj.intersect(map,map2));
	}

}
