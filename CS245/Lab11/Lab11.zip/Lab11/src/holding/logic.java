package holding;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class logic {

	HashMap<String, Integer> end = new HashMap<String, Integer>();

	
	public HashMap<String, Integer> intersect(HashMap<String, Integer> map1,HashMap<String, Integer> map2){

		for (Map.Entry<String, Integer> set : map1.entrySet()) {
			for (Map.Entry<String, Integer> set2 : map2.entrySet()) {
				if((set.getKey() == set2.getKey()) && (set.getValue() == set2.getValue())) {
					end.put(set.getKey(),set.getValue());
				}
			}
		    
		}
		return end;
		
	}
	
}
