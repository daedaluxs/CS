package holding;

import java.util.LinkedList;

/**
 * Keegan Grottodden
   This program demonstrates the partial 
   functionality of the LinkedList class.
*/

public class CS245_Lab_5
{  
   public static void main(String[] args)
   {  
      LinkedList<String> staff = new LinkedList<>();
      
      // adding elements to the list
      staff.addLast("Diana");
      staff.add("Susan");
      staff.addLast("Harry");
      staff.addLast("Romeo");
      staff.addLast("Tom");
      staff.add("Ahmed");
      
      
      // TASKS TO DO FOR LAB 5
      
      
      // (1) Print the elements of the list.
            System.out.println(staff);
            
      // (2) Add "Mary" to the front of the list & print the modified list.
            staff.addFirst("Mary");
            System.out.println(staff);
            
      // (3) Retrieve and print the 3rd element of the list.
            System.out.println(staff.get(2));
            
      // (4) Retrieve and print the element at the front of the list.
            System.out.println(staff.getFirst());
            
      // (5) Retrieve and print the element at the end of the list.
            System.out.println(staff.getLast());
            
      // (6) Remove the first element of the list & print the modified list.
            staff.removeFirst();
            System.out.println(staff);
            
      // (7) Retrieve and print the index of element "Jim" in the list.
      //     If the element is not in the list, prompt the user of the same. 
            if(!(staff.indexOf("Jim") == -1)){
               System.out.println(staff.indexOf("Jim"));
            }
            else{
               System.out.println("Not in list");
            }
            
      // (8) Change the first element to "Adriana" & print the modified list.
            staff.removeFirst();
            staff.addFirst("Adriana");
            System.out.println(staff);
   }
}

