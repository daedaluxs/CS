module Lab5 {
}