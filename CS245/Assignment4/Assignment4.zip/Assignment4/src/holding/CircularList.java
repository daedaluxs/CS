package holding;

import java.util.NoSuchElementException;
/**
 * 	Holds the circular list and its modifier methods.
 * @author keeganG
 *
 */
public class CircularList {

	class Node
	{  
		public Object data;
		public Node next;
	}
	
	private Node head;
	public Integer count = 0;
	
	/*
	 * New list
	 */
	public CircularList() {
		head = new Node();
	}
	/*
	 * Prints contents of list
	 */
	public void printRing() {
		   Node iterator = head.next;
		   System.out.print("Alive: ");
		   while (iterator != head) {
			   System.out.print(iterator.data + " ");
			   iterator = iterator.next;
		   }
		   System.out.println("");

	   }
	/*
	 * grabs first elements's held data
	 */
	public Object getFirst()
	   {  
	      if (head.next == null) { throw new NoSuchElementException(); }
	      return head.next.data;
	   }
	
	/*
	 * affix a new element to first position
	 */
	public void addFirst(Object element)
	   {  
	      Node temp = new Node();
	      temp.data = element;
	      temp.next = head.next;
	      count++;
	      
	      if (head.next == null) {
	    	  head.next = temp;
	    	  temp.next = head;
	      } else {    	  
	    	  head.next = temp;
	      }
	      
	   }
	/*
	 * remove current first element
	 */
	public Object removeFirst()
	   {  
	      if (head.next == null) { throw new NoSuchElementException(); }
	      
	      Object element = head.next.data;
	      head.next = head.next.next;
	      count--;
	      return element;
	   }
	/*
	 * searches for a string, removing it from the list.
	 */
	public void remove(String input) {
		   if (head.next == null || input == null || input == "") { 
			   throw new NoSuchElementException(); }
		   
		   Node previous = null;
		   Node iterator = head.next;
		   
		   while (iterator != head) {
			   if (iterator.data.toString().toLowerCase().equals(input.toString().toLowerCase())) {
				   if (previous == null) {
					   removeFirst();
				   } else {
					   previous.next = iterator.next;
					   iterator.next = null;
					   count--;
				   }
				   return;
			   }
			   //Cycle through
			   previous = iterator;
			   iterator = iterator.next;
		   }
		   //Triggers try catch, without adding again to graveyard list.
		   throw new NoSuchElementException();
	   }

}
