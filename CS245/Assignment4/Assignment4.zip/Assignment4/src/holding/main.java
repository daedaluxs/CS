package holding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
/*
 * Main Game. Type a living player's name and they enter the graveyard.
 * Last player alive is declared the winner. 
 */
public class main {

	private static CircularList killRing = new CircularList();
	private static LinkedList<String> graveyard = new LinkedList<String>();
	
	/*
	 * Main loop calling prompt() trigger.
	 */
	public static void main(String[] args) {
		readFile("player_names.txt");
		System.out.println(killRing.count.toString() + " Players Entered");
		//While someone has a friend...
		while(killRing.count > 1) {
			prompt();
		}
		
		System.out.println(killRing.getFirst() + " Wins");
	}
	/*
	 * Base trigger function for the main loop, calling other 
	 * functions in sequence.
	 */
	private static void prompt() {
		killRing.printRing();
		System.out.println("Kill Someone: ");
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String tokill = "";
		
		try {
			tokill = input.readLine();
		} catch(Exception e) {
			System.out.println("Someone Can't Type");
		}
		try {
			killRing.remove(tokill);
			graveyard.add(tokill);
			printGraveyard();
		} catch(Exception e) {
			System.out.println("Already dead/doesnt exist");
		}
	}
	/*
	 * Force-create a new file, and read from pre-existing into 
	 * a circular list object.
	 */
	private static void readFile(String filename) {
		File file = new File(filename);

		try{

			file.createNewFile();
		}
		catch(Exception e) {
			System.out.println("File Alreaddy Exists");
		}
		
		try {  
			
			FileReader fr = new FileReader(file);   
			BufferedReader br = new BufferedReader(fr); 
			String line = "";
			
			while((line = br.readLine()) != null) {   
				killRing.addFirst(line);
			}  
			
			fr.close();   
		} catch(Exception e) {  
			e.printStackTrace();  
		}  
	}
	
	
	private static void printGraveyard() {
		System.out.print("Dead: ");
		for (String p : graveyard) {
			System.out.print(p + " ");
		}
		System.out.println("");
	}
	
	
	
}
