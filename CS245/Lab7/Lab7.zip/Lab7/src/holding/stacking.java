package holding;

import java.util.Stack;

public class stacking {

	Stack<String>stack=new Stack<String>();
	String expression = "{(w * [x + y] / z) + a}";
	String nexpression = expression.replace(" ","");
	int count=0;
	public void finding() {
		for(int i=0;i<nexpression.length();i++) {
			char temp = nexpression.charAt(i);
			if(temp == '['  || temp=='{') {
				count++;
				String t = String.valueOf(temp);
				stack.push(t);
			}
			else {
				if(temp==']') {
					String popped = stack.pop();
					if(popped == "[") {
						System.out.println("cont.");
					}
				}
				if(temp=='}') {
					String popped = stack.pop();
					if(popped == "{") {
						System.out.println("cont.");
					}
				}
			}
			
		}
		if(count>0) {
			if(stack.empty()) {
				System.out.println("Balanced");
			}
			else {
				System.out.println("Un-Balanced");
	
			}
		}
		else {
			System.out.println("No-parenthesis");
		}
		
		
			
			
		
	}


}
