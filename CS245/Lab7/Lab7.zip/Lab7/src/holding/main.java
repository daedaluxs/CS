package holding;

import java.io.IOException;

public class main {

	static stacking obj = new stacking();
	public static void main(String args[]) throws IOException {

	obj.finding();

	}
}
