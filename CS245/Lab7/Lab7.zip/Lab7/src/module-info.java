module Lab7 {
}