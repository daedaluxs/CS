/**
   A program that demonstrates the LinkedList class
*/
public class ListDemo
{  

public static void main(String[] args)
   {  
      LinkedList list = new LinkedList();
      ListIterator iterator = list.listIterator();
      
      // Use the iterator so that list has (in order) these elements
      // Tom->Romeo->Harry->Diana->Juliet->Nina
      iterator.add("Tom");
      iterator.add("Romeo");
      iterator.add("Harry");
      iterator.add("Diana");
      iterator.add("Juliet");
      iterator.add("Nina");

      // Print all the elements of list
      iterator = list.listIterator();
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
      }
      System.out.println();
            
      // Call removeLast() to delete the last element of the list

      iterator.removeLast();
      
      // Print all the elements of list
      iterator = list.listIterator();
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
      }
      System.out.println();
   }
}

